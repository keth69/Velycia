module.exports = {
ownerNumber: [
    '6289507607701@s.whatsapp.net', 
    '200807102341121@lid' // <-- JID BARU DARI CONSOLE
  ], // Ganti dengan nomor owner (format: 628xxx)
  botName: 'Velycia',
  prefix: '.',
  sessionName: 'session',
  database: {
    rental: './database/rental.json',
    lists: './database/lists.json'
  }
};